class InvalidFileError(Exception):
    pass
